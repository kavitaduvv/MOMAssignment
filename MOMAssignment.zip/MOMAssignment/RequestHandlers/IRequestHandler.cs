﻿using Newtonsoft.Json.Linq;

namespace MOMAssignment.RequestHandlers
{
    public interface IRequestHandler
    {
        //Method to get the releases of the repo provided by the url
        string GetData(string url);
    }
}
