﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace MOMAssignment.Model
{
    public class Record
    {
        public string end_of_month { get; set; }
        public  string banks_fixed_deposits_3m { get; set; }
        public string banks_fixed_deposits_6m { get; set; }
        public string banks_fixed_deposits_12m { get; set; }
        public string banks_savings_deposits { get; set; }

        public string fc_fixed_deposits_3m { get; set; }
        public string fc_fixed_deposits_6m { get; set; }

        public string fc_fixed_deposits_12m { get; set; }

        public string fc_savings_deposits { get; set; }


    }

    public class RootObj
    {
        public List<Record> records { get; set; }
    }
}
