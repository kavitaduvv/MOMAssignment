﻿namespace MOMAssignment.Constants
{
    public static class RequestConstants
    {
      
        public const string BaseUrl = "https://eservices.mas.gov.sg/";
       
        public const string Url = "https://eservices.mas.gov.sg/api/action/datastore/search.json?resource_id=5f2b18a8-0883-4769-a635-879c63d3caac";
        public const string UserAgent = "User-Agent";
        public const string UserAgentValue = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36";
    }
}
